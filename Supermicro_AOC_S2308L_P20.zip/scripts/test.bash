#!/bin/bash

totallog="./total.log"
if [ -f "$totallog" ]; then
    rm "$totallog"
fi

yesno() {
  echo
  read -rp "$1 y/n: " var
  if [[ "$var" = "y" ]] || [[ "$var" = "Y" ]]; then
    true
   else
    false
  fi
}

clear
temp=$(echo $(( 16#$(./lsiutil.x86_64 -p1 -a 25,2,0,0 | grep IOCTemperature: | cut -dx -f2) )))
unit=$(echo $(( 16#$(./lsiutil.x86_64 -p1 -a 25,2,0,0 | grep IOCTemperatureUnits: | cut -dx -f2) )))
echo
echo "Adapter 1:"
echo "(Unit 2 = °C)"
echo
echo "Temp:  $temp °C"
echo "Unit:  $unit"
echo

lsblk

devs=({a..h})

echo
if yesno "10GB DD-Test starten? (sd${devs[0]}-sd${devs[-1]})"; then
  clear
  for dev in "${devs[@]}"; do
    tempfile="./sd$dev.temp"
    logfile="./sd$dev.log"
    if [ -f "$logfile" ]; then
      rm "$logfile"
    fi
    if [ -f "$tempfile" ]; then
      rm "$tempfile"
    fi
    tmux new-session -d -s sd$dev
    tmux send-keys -t sd$dev:0 "export PS1=''" Enter      # entfernt "root@host:~"
    tmux send-keys -t sd$dev:0 "echo /dev/sd$dev >> $tempfile" Enter
    tmux send-keys -t sd$dev:0 "dd if=/dev/zero of=/dev/sd$dev bs=1M count=10000 >> $tempfile 2>&1" Enter
    tmux send-keys -t sd$dev:0 "mv $tempfile $logfile" Enter
    tmux send-keys -t sd$dev:0 "exit" Enter
    echo "dd started for /dev/sd$dev"
  done
fi

echo
while true; do
    all_exist=true

    for dev in "${devs[@]}"; do
      logfile="./sd${dev}.log"
      if [ ! -f "$logfile" ]; then
        all_exist=false
      fi
    done

    if $all_exist; then
      echo "Alle Logfiles vorhanden."
      break
    fi

    echo "Warte auf Logfiles..."
    sleep 3
done

clear
for dev in "${devs[@]}"; do
  logfile="./sd$dev.log"
  echo
  cat $logfile
  echo >> $totallog
  cat $logfile >> $totallog
done

echo
echo
journalctl -k | grep -Ei "i/o error|blk_update_request|buffer i/o|end_request|timed out|timeout|retry|abort|reset|frozen|offline"
echo >> $totallog
journalctl -k | grep -Ei "i/o error|blk_update_request|buffer i/o|end_request|timed out|timeout|retry|abort|reset|frozen|offline" >> $totallog
echo >> $totallog

echo
echo "Script beendet."
echo 
