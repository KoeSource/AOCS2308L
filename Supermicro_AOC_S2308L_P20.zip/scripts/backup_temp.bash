#!/bin/bash

temp=$(echo $(( 16#$(./lsiutil.x86_64 -p1 -a 25,2,0,0 | grep IOCTemperature: | cut -dx -f2) )))
unit=$(echo $(( 16#$(./lsiutil.x86_64 -p1 -a 25,2,0,0 | grep IOCTemperatureUnits: | cut -dx -f2) )))
echo
echo "Adapter 1:"
echo "(Unit 2 = °C)"
echo
echo "Temp:  $temp °C"
echo "Unit:  $unit"
echo
