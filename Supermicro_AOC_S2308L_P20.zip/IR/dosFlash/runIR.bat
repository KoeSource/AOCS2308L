@echo off
cls
REM Einfacherer Flash Prozess
REM Original SMC2308x.bat
echo.
echo Supermicro
echo AOC-S2308L-L8i/e
echo IR = Raid Firmware
echo.
echo Write down SAS-Address now...
echo.
sas2flsh -o -listsasadd
echo.
echo Next Step, Create full Backup ...
pause
echo.
sas2flsh -o -uflash fullbackup.rom
echo.
echo Next Step, Erease complete Flash ...
pause
echo.
sas2flsh -o -e 7
echo.
echo Next Step, Flash new Firmware/BIOS ...
pause
echo.
sas2flsh -f 2308R207.ROM
sas2flsh -b mptsas2.rom
sas2flsh -b x64sas2.rom
echo.
echo Flash process done!
echo.
echo Next Step,
echo Set SAS-Adress manually,
echo the SAS-Adress is unique on each controller!
echo Example, invalid SAS-Adress:
echo     sas2flsh.exe -o -sasadd 910304801BACC700
echo.
pause